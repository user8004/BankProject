package com.utility;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

import com.connection.Connect;

public class AcctUtilDemo {
	public String active(boolean is_active)
	{
		
		String msg1="deactivated";
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the account no:-");
		Long acctNo=sc.nextLong();
		Connection con=null;
		
		
		try
		{
			con=Connect.getConnect();
			
			PreparedStatement stmt=con.prepareStatement("update registration_form set is_active=false where acct_no=?");
			stmt.setLong(1, acctNo);
			int i=stmt.executeUpdate();
			if(i>1)
			{
				System.out.println("updated");
			}
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return msg1;
	}
}
