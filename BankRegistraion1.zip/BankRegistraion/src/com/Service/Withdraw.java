package com.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.connection.Connect;

public class Withdraw
{
	Connection con=null;
	Long acctNo;
	Long withdrawAmt;
	Long origAmt;
	public Long withdraw()

	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your account no");//240420231006
		acctNo=sc.nextLong();
		System.out.println("enter the amount to withdraw");
		withdrawAmt=sc.nextLong();
		ResultSet rs1;
		int rs2;
		try
		{
			con=Connect.getConnect();
			String query="Select amout from registration_form";
			
			PreparedStatement stmt=con.prepareStatement(query);
			
			rs1=stmt.executeQuery();
			while (rs1.next())
			{
				origAmt=rs1.getLong(1);
				break;
			}
			String query1="update registration_form set amout=? where acct_no=?";
			PreparedStatement stmt1=con.prepareStatement(query1);
			if(withdrawAmt>=origAmt)
			{
				throw new IllegalArgumentException ("Dont pass negative value");
			}
			origAmt=origAmt-withdrawAmt;
			
			stmt1.setLong(1, origAmt);
			stmt1.setLong(2, acctNo);
			
			rs2=stmt1.executeUpdate();
			if(rs2>1)
			{
				System.out.println("amt updated");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return origAmt;
	}
}
