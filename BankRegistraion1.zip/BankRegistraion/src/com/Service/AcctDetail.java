package com.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.connection.Connect;
import com.controller.Form;

public class AcctDetail {
	public String getDetail()
	{
		String msg="";
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the account no:-");
		Long acctNo=sc.nextLong();
		Connection con=null;
		try
		{
			con=Connect.getConnect();
			
			PreparedStatement stmt=con.prepareStatement("select * from registration_form where acct_no=?");
			stmt.setLong(1, acctNo);
			ResultSet rs= stmt.executeQuery();
			while(rs.next())
			{
				System.out.println(rs.getString("name"));
				System.out.println(rs.getString("address"));
				System.out.println(rs.getString("mobile_no"));
				System.out.println(rs.getString("acct_no"));
				System.out.println(rs.getString("user_name"));
				System.out.println(rs.getString("password"));
				System.out.println(rs.getString("amout"));
				System.out.println(rs.getString("is_active"));
				System.out.println(rs.getString("created_date"));
				
			}
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return msg;
	}

}
