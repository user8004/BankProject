package com.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.connection.Connect;

public class ChangeMobNo {
	Connection con=null;
	Long acctNo;
	Long newmobNo;
	
	void changeMobNo()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your account no");//240420231006
		acctNo=sc.nextLong();
		System.out.println("enter the new MobNo");
		newmobNo=sc.nextLong();
		ResultSet rs1;
		
		try
		{
			con=Connect.getConnect();
			
			String query1="update registration_form set mobile_no=? where acct_no=?";
			PreparedStatement stmt1=con.prepareStatement(query1);
			
			stmt1.setLong(1, newmobNo);
			stmt1.setLong(2, acctNo);
			
			stmt1.executeUpdate();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		System.out.println("contact no updated");
	}
}
