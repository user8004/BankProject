package com.Service;

import java.sql.Connection;
import java.util.Scanner;

import com.connection.Connect;
import com.utility.AcctUtilDemo;
;
//import com.utility.AcctUtilDemo;

public class LoginService {
public void displayOption()
{
		 Connection con=Connect.getConnect();
		 
          Scanner sc =new Scanner(System.in);
          System.out.println("Press1 check acct details");
      	System.out.println("Press2 withdraw amt");
      	System.out.println("Press3 deposit amt");
      	System.out.println("Press4 Mobile no update" );
      	System.out.println("Press5 Acct del");
      	
      	System.out.println("Press6 forget password");
      	
          
          int option=sc.nextInt();
          switch(option)
          {
          case 1:System.out.println("acctDetails");
          AcctDetail acctdetail=new AcctDetail();
          acctdetail.getDetail();
         break;
          case 2:System.out.println("withdrawAmt");
           Withdraw withdraw=new Withdraw();
         Long res= withdraw.withdraw();
         System.out.println("New amount is"+res);
          break;
          case 3:System.out.println("depositAmt");
          Deposite deposit=new Deposite();
          deposit.deposit();
          
          break;
          case 4:System.out.println("updateMobNo");
          ChangeMobNo no=new ChangeMobNo();
          no.changeMobNo();
          
          break;
          case 5:System.out.println("acctDeactivate");
          AcctUtilDemo acctutildemo=new AcctUtilDemo();
          String s=acctutildemo.active(true);
          System.out.println(s);
          
          break;
          case 6:System.out.println("changePassword");
          
          
          break;

          
    
          }
          sc.close();
          
	}

	
	
	
	
	
	

}
